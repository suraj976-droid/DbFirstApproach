﻿using DbFirstApproach.Models;
using Microsoft.AspNetCore.Mvc;

namespace DbFirstApproach.Controllers
{
    public class Student : Controller
    {
        private readonly JanbatchcoreSpmvcContext db;

        public Student(JanbatchcoreSpmvcContext db)
        {
            this.db = db;
        }
        public IActionResult Index()
        {
           var data =  db.Students.ToList();
            return View(data);
        }
    }
}
