﻿using System;
using System.Collections.Generic;

namespace DbFirstApproach.Models;

public partial class Employee
{
    public int Eid { get; set; }

    public string Ename { get; set; } = null!;

    public double Esalary { get; set; }

    public int Mid { get; set; }

    public virtual Manager MidNavigation { get; set; } = null!;
}
