﻿using System;
using System.Collections.Generic;

namespace DbFirstApproach.Models;

public partial class Emp
{
    public int Eid { get; set; }

    public string Ename { get; set; } = null!;

    public string Email { get; set; } = null!;

    public double Esalary { get; set; }

    public string Eimg { get; set; } = null!;
}
