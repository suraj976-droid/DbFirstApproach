﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace DbFirstApproach.Models;

public partial class JanbatchcoreSpmvcContext : DbContext
{
    public JanbatchcoreSpmvcContext()
    {
    }

    public JanbatchcoreSpmvcContext(DbContextOptions<JanbatchcoreSpmvcContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Emp> Emps { get; set; }

    public virtual DbSet<Employee> Employees { get; set; }

    public virtual DbSet<Manager> Managers { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<Student> Students { get; set; }

  

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Emp>(entity =>
        {
            entity.HasKey(e => e.Eid);

            entity.ToTable("emps");

            entity.Property(e => e.Eid).HasColumnName("eid");
            entity.Property(e => e.Eimg).HasColumnName("eimg");
            entity.Property(e => e.Email).HasColumnName("email");
            entity.Property(e => e.Ename).HasColumnName("ename");
            entity.Property(e => e.Esalary).HasColumnName("esalary");
        });

        modelBuilder.Entity<Employee>(entity =>
        {
            entity.HasKey(e => e.Eid);

            entity.ToTable("employee");

            entity.HasIndex(e => e.Mid, "IX_employee_Mid");

            entity.Property(e => e.Eid).HasColumnName("eid");
            entity.Property(e => e.Ename).HasColumnName("ename");
            entity.Property(e => e.Esalary).HasColumnName("esalary");

            entity.HasOne(d => d.MidNavigation).WithMany(p => p.Employees).HasForeignKey(d => d.Mid);
        });

        modelBuilder.Entity<Manager>(entity =>
        {
            entity.HasKey(e => e.Mid);

            entity.ToTable("manager");
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.Pid);

            entity.ToTable("products");
        });

        modelBuilder.Entity<Student>(entity =>
        {
            entity.HasKey(e => e.Sid);

            entity.ToTable("students");

            entity.Property(e => e.Sname).HasColumnName("SName");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
