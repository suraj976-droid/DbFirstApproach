﻿using System;
using System.Collections.Generic;

namespace DbFirstApproach.Models;

public partial class Manager
{
    public int Mid { get; set; }

    public string Mname { get; set; } = null!;

    public string Dname { get; set; } = null!;

    public virtual ICollection<Employee> Employees { get; } = new List<Employee>();
}
