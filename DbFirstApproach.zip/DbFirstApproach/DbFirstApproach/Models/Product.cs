﻿using System;
using System.Collections.Generic;

namespace DbFirstApproach.Models;

public partial class Product
{
    public int Pid { get; set; }

    public string Pname { get; set; } = null!;

    public string Pcat { get; set; } = null!;

    public double Price { get; set; }
}
